<?php
/**
 * Use the same as `content-job_listing.php`
 *
 * @package Jobify
 * @since 3.0.0
 * @version 3.8.0
 */

get_template_part( 'content', 'job_listing' );
